<footer class="main-footer fixed-bottom">
    <strong>Copyright &copy; <?php echo date('Y');?> 
    <a href="https://strathmore.edu/">Strathmore University</a>.</strong> All rights reserved.
    <div class="float-right d-sm-block">
      Nairobi Hospice
    </div>
  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>